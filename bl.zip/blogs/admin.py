# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from blogs.models import Blog ,Category
# Register your models here.
admin.site.register(Blog)
admin.site.register(Category)
