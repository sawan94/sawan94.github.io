from rest_framework import serializers
from blogs.models import Blog
from users.serializers import AuthorSerializer
from django.conf import settings

class BlogMiniSerializer(serializers.ModelSerializer):
    author = AuthorSerializer(source="added_by")
    thumbnail = serializers.SerializerMethodField()

    class Meta:
        model = Blog
        fields = ('id', 'title','summary','author','date_published','thumbnail','slug')
    
    def get_thumbnail(self, obj):
        return settings.SITE_URL+(obj.thumbnail.url)