# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from users.models import User
from django.utils.translation import gettext as _

# Create your models here.

class Category(models.Model):
    name = models.CharField(_('name'), max_length=128)
    slug = models.CharField(_('slug'), max_length=128)
    
    class Meta:
        verbose_name = _('category')
        verbose_name_plural = _('categories')

class Blog(models.Model):
    title = models.CharField(_('title'), max_length=128)
    summary = models.CharField(_('summary'), max_length=512)
    slug = models.CharField(_('slug'), max_length=128,unique=True)
    date_added = models.DateTimeField(_('date joined'), auto_now_add=True)
    date_published = models.DateTimeField(_('date published'), null=True, blank = True)
    is_published = models.BooleanField(_('published'), default=False)
    added_by = models.ForeignKey(User, null=False)
    categories = models.ManyToManyField(Category)
    thumbnail  = models.ImageField(upload_to = 'uploads/images/blog_thumb/', default = 'uploads/images/blog_thumb/no-img.png')

    class Meta:
        verbose_name = _('blog')
        verbose_name_plural = _('blogs')

