from django.conf.urls import *
from blogs.views import BlogView,BlogsView

urlpatterns = [
    url(r'^$',BlogsView.as_view() ),
    url(r'(?P<slug>[\w-]+)$',BlogView.as_view({'get': 'retrieve'}) )
]