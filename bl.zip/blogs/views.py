# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from rest_framework import generics
from blogs.models import Blog
from blogs.serializers import BlogMiniSerializer,BlogFullSerializer
from rest_framework.mixins import RetrieveModelMixin
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework.views import APIView

# Create your views here.

class CommonView(APIView):
    queryset = Blog.objects.filter(is_published=True).all()

    def get_serializer(self, *args, **kwargs):
        serializer_type = self.request.GET.get("serializer") if "serializer" in self.request.GET else "mini"
        if serializer_type == "full":
            return BlogFullSerializer(*args, **kwargs)
        else:
            return BlogMiniSerializer(*args, **kwargs)

class BlogsView(CommonView,generics.ListAPIView):
    def get_queryset(self):
        queryset = super(BlogsView,self).get_queryset()
        if "filter" in self.request.GET:
            filter_type = self.request.GET.get("filter")
            if filter_type == "latest":
                queryset = queryset.order_by("-date_published")
            if filter_type == "top":
                queryset = queryset.order_by("-date_published")
            if filter_type == "sticky":
                queryset = queryset.filter(sticky=True).order_by("-date_published")
            if filter_type == "today":
                queryset = queryset.filter(today_pick=True).order_by("-date_published")
            if filter_type == "dont_miss":
                queryset = queryset.filter(dont_miss=True).order_by("-date_published")
            if filter_type == "similar":
                queryset = queryset.order_by("?")
        return queryset

class BlogView(CommonView,viewsets.ModelViewSet):
    lookup_field = "slug"