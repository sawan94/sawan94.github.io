# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from rest_framework import generics
from blogs.models import Blog
from blogs.serializers import BlogMiniSerializer
from rest_framework.mixins import RetrieveModelMixin
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework.views import APIView

# Create your views here.

class CommonView(APIView):
    queryset = Blog.objects.filter(is_published=True).all()

    def get_serializer(self, *args, **kwargs):
        serializer_type = self.request.GET.get("serializer") if "serializer" in self.request.GET else "mini"
        if serializer_type == "full":
            return serializer_class(*args, **kwargs)
        else:
            return BlogMiniSerializer(*args, **kwargs)

class BlogsView(CommonView,generics.ListAPIView):
    pass

class BlogView(CommonView,viewsets.ModelViewSet):
    lookup_field = "slug"