from rest_framework import serializers
from users.models import User

class AuthorSerializer(serializers.ModelSerializer):
    name = serializers.CharField(source="get_full_name")

    class Meta:
        model = User
        fields = ('id', 'name')